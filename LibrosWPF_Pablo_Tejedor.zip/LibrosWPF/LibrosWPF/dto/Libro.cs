﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibrosWPF.dto
{
    public class Libro : INotifyPropertyChanged, ICloneable, IDataErrorInfo
    {
        private String titulo;
        public String Titulo
        { 
            get{
                return titulo;
            }
            set
            {
                titulo = value;
                this.PropertyChanged(this, new PropertyChangedEventArgs("Titulo"));
            }

        }
        private String autor;
        public String Autor
        {
            get
            {
                return autor;
            }
            set
            {
                autor = value;
                this.PropertyChanged(this, new PropertyChangedEventArgs("Autor"));
            }
        }
        private DateTime fechaEntrada;
        public DateTime FechaEntrada
        {
            get
            {
                return fechaEntrada;
            }
            set
            {
                fechaEntrada = value;
                this.PropertyChanged(this, new PropertyChangedEventArgs("FechaEntrada"));
            }
        }
        // Constructor sobre cargado de Libro, para añadir libros y no tener que indicar la fecha, ya que obtiene la del momento en el que añadimos
        // el libro
        public Libro()
        {
            this.fechaEntrada = DateTime.Now;
        }

        // Constructor basico de Libro
        public Libro(String titulo, String autor, DateTime fechaEntrada)
        {
            this.titulo = titulo;
            this.autor = autor;
            this.fechaEntrada = fechaEntrada;
        }
        public event PropertyChangedEventHandler PropertyChanged;

        // Metodo Clone() sobreescrito para poder trabajar con el
        public object Clone()
        {
            // Devuelve una copia del objeto, es decir, clona el objeto y todos sus atributos.
            return this.MemberwiseClone();
        }

        // 
        public string Error
        {
            get { return ""; }
        }
        // En caso de tener el campo Titulo o el Campo Autor vacios o nulos, nos indica el error mediante texto.
        public string this[string columName]
        {
            get
            {
                string resultado = "";
                if(columName == "Titulo")
                {
                    if (string.IsNullOrEmpty(titulo)) {
                        resultado = "Debes introducir un Titulo para el Libro";
                    }
                        
                }
                if(columName == "Autor")
                {
                    if (string.IsNullOrEmpty(autor)){
                        resultado = "Debes introducir un Autor para el Libro";
                    }
                        
                }
                return resultado;
                    
            }
        }
    }
}

