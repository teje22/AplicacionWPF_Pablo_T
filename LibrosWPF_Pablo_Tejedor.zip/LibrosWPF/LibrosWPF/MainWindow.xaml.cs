﻿using LibrosWPF.dto;
using LibrosWPF.Logica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LibrosWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private LogicaNegocio logicaNegocio;
        public MainWindow()
        {
            InitializeComponent();
            logicaNegocio = new LogicaNegocio();
            // Establecemos un dataContext para un componente concreto
            // El DataContext de nuestra tabla llamada DataGridLibros es logicaNegocio
            DataGridLibros.DataContext = logicaNegocio;
        }

        // Evento para añadir un nuevo libro a la lista, abrimos la ventana DialogoLibro pasandole la logica de negocio para poder trabajar con ella
        private void NuevoMenuItem_Click(object sender, RoutedEventArgs e)
        {
            DialogoLibro dialogoLibro = new DialogoLibro(logicaNegocio);
            dialogoLibro.Show();
        }

        private void buttonModificar_Click(object sender, RoutedEventArgs e)
        {
            // Si el libro no esta vacío
            if(DataGridLibros.SelectedIndex != -1)
            {
                // Guardamos el libro seleccionado
                Libro libro = (Libro) DataGridLibros.SelectedItem;
                // Abrimos la ventana DialoLibro, pasandole nuestra logica, el libro y la posicion de dicho libro
                // NOTA: Debemos mandar una copia con un .Clone(), el cual dicho metodo lo sobrescribimos en la clase Libro,
                //       para que no nos modifique la lista real, hasta que no aceptemos.
                DialogoLibro dialogoLibro = new DialogoLibro(logicaNegocio, (Libro)libro.Clone(), DataGridLibros.SelectedIndex);
                // Mostramos la pantalla
                dialogoLibro.Show();
            }
            
        }

        // Evento del boton eliminar
        private void buttonEliminar_Click(object sender, RoutedEventArgs e)
        {
            // Si el libro no está vacion (hay algo en esa posicion)
            if (DataGridLibros.SelectedIndex != -1)
            {
                // Sacamos el objeto libro del DataGrid
                Libro libro = (Libro)DataGridLibros.SelectedItem;
                // Llamamos a nuestro metodo eliminar libro que creamos en logicaNegocio
                logicaNegocio.eliminarLibro(libro);
            }
        }

        // Evento del bottonAutor el cual obtiene el texto de dos campos y llamamos al metodo modificarLibro sobrecargado,
        // pasandole el autor Antiguo y el autor nuevo
        private void buttonAutor_Click(object sender, RoutedEventArgs e)
        {
            string autorNuevo = textAutorNuevo.Text;
            string autorViejo = textAutorViejo.Text;
            logicaNegocio.modificarLibro(autorNuevo, autorViejo);
        }
    }
}
