﻿using LibrosWPF.dto;
using LibrosWPF.Logica;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibrosWPF
{
    /// <summary>
    /// Lógica de interacción para DialogoLibro.xaml
    /// </summary>
    public partial class DialogoLibro : Window
    {
        private LogicaNegocio logicaNegocio;
        public Libro libro;
        private int posicion;
        private Boolean modificar;
        private int errores;
        public DialogoLibro(LogicaNegocio logicaNegocio)
        {
            InitializeComponent();
            this.logicaNegocio = logicaNegocio;
            libro = new Libro();
            // Establecemos como contexto de este dialogo el libro, es decir, el DataContext de todos los componentes de esta ventana
            // son el libro.
            this.DataContext = libro;
            modificar = false;
        }
        // Segundo constructor sobrecargado
        public DialogoLibro(LogicaNegocio logicaNegocio, Libro libroModificado, int pos)
        {
            InitializeComponent();
            this.logicaNegocio = logicaNegocio;
            this.libro = libroModificado;
            this.posicion = pos;
            this.DataContext = libro;
            modificar = true;
        }

        private void buttonCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void buttonAceptar_Click(object sender, RoutedEventArgs e)
        {
            if (modificar)
            {
                // NOTA: Realizamos dos operaciones con el mismo botón, dependiendo si el usuario modifica uno existente o crea uno nuevo.
                //       comprobando la variable modificar, la cual cambia su valo dependiendo del constructor que abra esta ventana
                logicaNegocio.modificarLibro(libro, posicion);
            } else
            {
                logicaNegocio.aniadirLibro(libro);
            }

            // Una vez hayamos acabado cerramos la pantalla.
            this.Close();
        }
        // Comprobamos si hay algun error para habilitar el botón de aceptar, el cual por defecto está deshabilitado hasta que no haya errores.
        private void Validation_Error(object sender, ValidationErrorEventArgs e)
        {
            if (e.Action == ValidationErrorEventAction.Added)
                errores++;
            else
                errores--;
            if (errores == 0)
                buttonAceptar.IsEnabled = true;
            else
                buttonAceptar.IsEnabled = false;
        }

        // Dos eventos de entrada y salida de los botones aceptar y cancelar que cambian el color del fondo.
        private void buttonAceptar_MouseEnter(object sender, MouseEventArgs e)
        {
            buttonAceptar.Background = Brushes.Aqua;
        }

        private void buttonCancelar_MouseLeave(object sender, MouseEventArgs e)
        {
            buttonCancelar.Background = Brushes.Red;
        }

        // Evento que cambia el borde del componente al perder el foco
        private void datePickerEntrada_LostFocus(object sender, RoutedEventArgs e)
        {
            datePickerEntrada.BorderBrush = Brushes.AliceBlue;
        }
    }
}
