﻿using LibrosWPF.dto;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibrosWPF.Logica
{
    public class LogicaNegocio
    {
        public ObservableCollection<Libro> listaLibros { get; set; }

        // Constructor de listaLibros, el cual introducimos un libro junto con este constructor
        public LogicaNegocio()
        {
            listaLibros = new ObservableCollection<Libro>();
            listaLibros.Add(new Libro("Un libro", "Autor", DateTime.Now));
        }

        // Método añadir libros a nuestra lista de libros
        public void aniadirLibro(Libro libro)
        {
            listaLibros.Add(libro);
        }
        // La posicion del metodo modificarLibro va a coincidir con la posicion de la lista, gracias al Binding (0,1,2...)
        public void modificarLibro(Libro libro, int posicion)
        {
            listaLibros[posicion] = libro;
        }
        // Sobrecargamos el método modificarLibro para cambiar todos los autores que se llamen de la misma forma dentro de la tabla,
        // por otro autor.
        public void modificarLibro(string autorNuevo, string autorViejo)
        {
            foreach (Libro libro in listaLibros)
            {
                if (libro.Autor.Equals(autorViejo))
                {
                    libro.Autor = autorNuevo;
                }
            }
        }
        // Método para borrar libros de nuestra libreria
        public void eliminarLibro(Libro libro)
        {
            listaLibros.Remove(libro);
        }
    }
}
